/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.biblioteca;

/**
 *
 * @author damon
 */
import java.util.Scanner;

public class Biblioteca {
    private static ListaEnlazadaSimple listaLibros = new ListaEnlazadaSimple();
    private static ListaEnlazadaDoble listaAutores = new ListaEnlazadaDoble();
    private static ArbolBinarioBusqueda arbolCategorias = new ArbolBinarioBusqueda();
    private static colaPrestamos colaPrestamos = new colaPrestamos();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("~~~Menu Principal~~~");
            System.out.println("1.~ Gestionar Categorias");
            System.out.println("2.~ Gestionar Autores");
            System.out.println("3.~ Gestionar Libros");
            System.out.println("4.~ Prestamo de Libros");
            System.out.println("5.~ Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    menuCategorias(scanner);
                    break;
                case 2:
                    menuAutores(scanner);
                    break;
                case 3:
                    menuLibros(scanner);
                    break;
                case 4:
                    menuPrestamos(scanner);
                    break;
                case 5:
                    System.out.println("Hasta pronto °^°");
                    break;
                default:
                    System.out.println("Opcion invalida, porfavor intentelo de nuevo");
            }
        } while (opcion != 5);
    }

    private static void menuCategorias(Scanner scanner) {
        int opcion;
        do {
            System.out.println("~~~Menu Categorias~~~");
            System.out.println("1.~ Crear nueva categoria");
            System.out.println("2.~ Editar categoria existente");
            System.out.println("3.~ Eliminar categoria");
            System.out.println("4.~ Mostrar lista de categorias");
            System.out.println("5.~ Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre de la nueva categoria: ");
                    String nombreCategoria = scanner.nextLine();
                    arbolCategorias.agregar(nombreCategoria);
                    break;
                case 2:
                    System.out.print("Ingrese el nombre de la categoria a editar: ");
                    nombreCategoria = scanner.nextLine();
                    Categoria categoria = arbolCategorias.buscar(nombreCategoria);
                    if (categoria != null) {
                        System.out.print("Ingrese el nuevo nombre de la categoria: ");
                        String nuevoNombre = scanner.nextLine();
                        categoria.setNombre(nuevoNombre);
                    } else {
                        System.out.println("Categoria no encontrada");
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el nombre de la categoría a eliminar: ");
                    nombreCategoria = scanner.nextLine();
                    if (!arbolCategorias.eliminar(nombreCategoria)) {
                        System.out.println("No se puede eliminar la categoría ya que esta asociada a un libro");
                    }
                    break;
                case 4:
                    if (arbolCategorias.estaVacio()){
                        System.out.println("No hay categorias disponibles");
                    }else{
                    arbolCategorias.mostrar();
                    }
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opcion invalida, porfavor intentelo de nuevo.");
            }
        } while (opcion != 5);
    }

    private static void menuAutores(Scanner scanner) {
        int opcion;
        do {
            System.out.println("~~~Menu Autores~~~");
            System.out.println("1.~ Crear autor");
            System.out.println("2.~ Editar autor");
            System.out.println("3.~ Eliminar autor");
            System.out.println("4.~ Mostrar lista de autores");
            System.out.println("5.~ Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del nuevo autor: ");
                    String nombreAutor = scanner.nextLine();
                    listaAutores.agregar(new Autor(nombreAutor));
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del autor a editar: ");
                    nombreAutor = scanner.nextLine();
                    Autor autor = listaAutores.buscar(nombreAutor);
                    if (autor != null) {
                        System.out.print("Ingrese el nuevo nombre del autor: ");
                        String nuevoNombre = scanner.nextLine();
                        autor.setNombre(nuevoNombre);
                    } else {
                        System.out.println("El autor no ha sido encontrado");
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el nombre del autor a eliminar: ");
                    nombreAutor = scanner.nextLine();
                    if (!listaAutores.eliminar(nombreAutor)) {
                        System.out.println("No se puede eliminar el autor ya que esta asociado a un libro");
                    }
                    break;
                case 4:
                    if (listaAutores.estaVacia()) {
                        System.out.println("No hay autores disponibles");
                    } else {
                    listaAutores.mostrar();
                    }
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opcion invalida, porfavor intentelo de nuevo.");
            }
        } while (opcion != 5);
    }

    private static void menuLibros(Scanner scanner) {
        int opcion;
        do {
            System.out.println("~~~Menu Libros~~~");
            System.out.println("1.~ Crear libro");
            System.out.println("2.~ Editar libro");
            System.out.println("3.~ Eliminar libro");
            System.out.println("4.~ Mostrar lista de Libros");
            System.out.println("5.~ Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    if (listaAutores.estaVacia() || arbolCategorias.estaVacio()) {
                        System.out.println("Debe existir al menos un autor y una categoria para la creacion de un libro.");
                        break;
                    }
                    System.out.print("Ingrese el titulo del libro: ");
                    String tituloNuevoLibro = scanner.nextLine();
                    System.out.print("Ingrese el nombre del autor: ");
                    String nombreAutorNuevoLibro = scanner.nextLine();
                    Autor autorNuevoLibro = listaAutores.buscar(nombreAutorNuevoLibro);
                    if (autorNuevoLibro == null) {
                        System.out.println("Autor no encontrado.");
                        break;
                    }
                    System.out.print("Ingrese el nombre de la categoria: ");
                    String nombreCategoriaNuevoLibro = scanner.nextLine();
                    Categoria categoriaNuevoLibro = arbolCategorias.buscar(nombreCategoriaNuevoLibro);
                    if (categoriaNuevoLibro == null) {
                        System.out.println("Categoria no encontrada.");
                        break;
                    }
                    listaLibros.agregar(new Libro(tituloNuevoLibro, autorNuevoLibro, categoriaNuevoLibro));
                    break;
                case 2:
                     System.out.print("Ingrese el titulo del libro a editar: ");
                    String tituloLibroEditar = scanner.nextLine();
                    Libro libro = listaLibros.buscar(tituloLibroEditar);
                    if (libro != null) {
                        System.out.print("Ingrese el nuevo titulo del libro: ");
                        String nuevoTituloLibro = scanner.nextLine();
                        libro.setTitulo(nuevoTituloLibro);
                        System.out.print("Ingrese el nuevo nombre del autor: ");
                        String nuevoNombreAutorLibro = scanner.nextLine();
                        Autor nuevoAutorLibro = listaAutores.buscar(nuevoNombreAutorLibro);
                        if (nuevoAutorLibro != null) {
                            libro.setAutor(nuevoAutorLibro);
                        } else {
                            System.out.println("Autor no encontrado.");
                        }
                        System.out.print("Ingrese el nuevo nombre de la categoria: ");
                        String nuevoNombreCategoriaLibro = scanner.nextLine();
                        Categoria nuevaCategoriaLibro = arbolCategorias.buscar(nuevoNombreCategoriaLibro);
                        if (nuevaCategoriaLibro != null) {
                            libro.setCategoria(nuevaCategoriaLibro);
                        } else {
                            System.out.println("Categoria no encontrada.");
                        }
                    } else {
                        System.out.println("Libro no encontrado.");
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el titulo del libro a eliminar: ");
                    String tituloLibro = scanner.nextLine();
                    listaLibros.eliminar(tituloLibro);
                    break;
                case 4:
                    if (listaLibros.estaVacia()) {
                        System.out.println("No hay libros disponibles.");
                    } else {
                        listaLibros.mostrar();
                    }
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opcion invalida, porfavor intentelo de nuevo.");
            }
        } while (opcion != 5);
    }

    private static void menuPrestamos(Scanner scanner) {
        int opcion;
        do {
            System.out.println("~~~Menu de Prestamos~~~");
            System.out.println("1.~ Mostrar lista de libros prestados");
            System.out.println("2.~ Mostrar lista de libros disponibles");
            System.out.println("3.~ Prestar un libro");
            System.out.println("4.~ Devolver un libro");
            System.out.println("5.~ Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    colaPrestamos.mostrarPrestamos();
                    break;
                case 2:
                     if (listaLibros.estaVacia()) {
                    System.out.println("No hay libros disponibles.");
                } else {
                    listaLibros.mostrarDisponibles(colaPrestamos);
                }
                    break;
                case 3:
                    if (listaLibros.estaVacia()) {
                    System.out.println("No hay libros disponibles para prestar.");
                    break;
                }
                    System.out.print("Ingrese el titulo del libro a pedir prestado: ");
                    String tituloLibroPrestar = scanner.nextLine();
                    Libro libroPrestar = listaLibros.buscar(tituloLibroPrestar);
                    if (libroPrestar != null && !colaPrestamos.estaPrestado(libroPrestar)) {
                        colaPrestamos.prestar(libroPrestar);
                        System.out.println("Te hemos prestado el libro correctamente.");
                } else {
                    System.out.println("El ibro no esta disponible para prestamo.");
                }
                    break;
                case 4:
                    colaPrestamos.devolver();
                    System.out.println("El libro ha sido devuelto.");
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opcion invalida, porfavor intentelo de nuevo.");
            }
        } while (opcion != 5);
    }
}