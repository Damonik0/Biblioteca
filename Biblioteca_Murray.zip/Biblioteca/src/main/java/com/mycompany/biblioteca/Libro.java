/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author damon
 */
public class Libro {
    private String titulo;
    private Autor autor;
    private Categoria categoria;

    public Libro(String titulo, Autor autor, Categoria categoria) {
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Titulo: " + titulo + ", Autor: " + autor.getNombre() + ", Categoria: " + categoria.getNombre();
    }
}

class ListaEnlazadaSimple {
    private Nodo cabeza;
    
    private class Nodo {
        private Libro libro;
        private Nodo next;

        public Nodo(Libro libro) {
            this.libro = libro;
        }
    }

    public void agregar(Libro libro) {
        Nodo nuevoNodo = new Nodo(libro);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = nuevoNodo;
        }
    }

    public void mostrar() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.println(temp.libro);
            temp = temp.next;
        }
    }
    public void mostrarDisponibles(colaPrestamos Prestamos) {
        Nodo temp = cabeza;
        while (temp != null) {
            if (!Prestamos.estaPrestado(temp.libro)) {
                System.out.println(temp.libro);
            }
            temp = temp.next;
        }
    }

    public Libro buscar(String titulo) {
        Nodo temp = cabeza;
        while (temp != null) {
            if (temp.libro.getTitulo().equals(titulo)) {
                return temp.libro;
            }
            temp = temp.next;
        }
        return null;
    }

    public void eliminar(String titulo) {
        if (cabeza == null) return;

        if (cabeza.libro.getTitulo().equals(titulo)) {
            cabeza = cabeza.next;
            return;
        }

        Nodo temp = cabeza;
        while (temp.next != null) {
            if (temp.next.libro.getTitulo().equals(titulo)) {
                temp.next = temp.next.next;
                return;
            }
            temp = temp.next;
        }
    }
    public boolean estaVacia() {
        return cabeza == null;
    }
}
