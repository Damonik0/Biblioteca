/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author damon
 */
public class Autor {
    private String nombre;
    private Autor prev;
    private Autor next;

    public Autor(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Autor getPrev() {
        return prev;
    }

    public void setPrev(Autor prev) {
        this.prev = prev;
    }

    public Autor getNext() {
        return next;
    }

    public void setNext(Autor next) {
        this.next = next;
    }
}

class ListaEnlazadaDoble {
    private Autor cabeza;

    public void agregar(Autor autor) {
        if (cabeza == null) {
            cabeza = autor;
        } else {
            Autor temp = cabeza;
            while (temp.getNext() != null) {
                temp = temp.getNext();
            }
            temp.setNext(autor);
            autor.setPrev(temp);
        }
    }

    public void mostrar() {
        Autor temp = cabeza;
        while (temp != null) {
            System.out.println(temp.getNombre());
            temp = temp.getNext();
        }
    }

    public Autor buscar(String nombre) {
        Autor temp = cabeza;
        while (temp != null) {
            if (temp.getNombre().equals(nombre)) {
                return temp;
            }
            temp = temp.getNext();
        }
        return null;
    }

    public boolean eliminar(String nombre) {
        Autor temp = cabeza;

        if (temp == null) return false;

        if (temp.getNombre().equals(nombre)) {
            if (temp.getNext() != null) {
                temp.getNext().setPrev(null);
            }
            cabeza = temp.getNext();
            return true;
        }

        while (temp != null) {
            if (temp.getNombre().equals(nombre)) {
                if (temp.getPrev() != null) {
                    temp.getPrev().setNext(temp.getNext());
                }
                if (temp.getNext() != null) {
                    temp.getNext().setPrev(temp.getPrev());
                }
                return true;
            }
            temp = temp.getNext();
        }
        return false;
    }
     public boolean estaVacia() {
        return cabeza == null;
    }
}