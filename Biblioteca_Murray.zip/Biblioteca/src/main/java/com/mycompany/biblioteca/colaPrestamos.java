/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;
import java.util.LinkedList;
import java.util.Queue;
/**
 *
 * @author damon
 */
public class colaPrestamos {
    private Queue<Libro> prestamos = new LinkedList<>();

    public void prestar(Libro libro) {
        prestamos.add(libro);
    }

    public void devolver() {
        prestamos.poll();
    }

    public void mostrarPrestamos() {
        for (Libro libro : prestamos) {
            System.out.println(libro);
        }
    }

    public boolean estaPrestado(Libro libro) {
        return prestamos.contains(libro);
    }
}