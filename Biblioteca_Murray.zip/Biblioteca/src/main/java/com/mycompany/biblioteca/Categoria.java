/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author damon
 */
public class Categoria {
    private String nombre;
    private Categoria left;
    private Categoria right;

    public Categoria(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Categoria getLeft() {
        return left;
    }

    public void setLeft(Categoria left) {
        this.left = left;
    }

    public Categoria getRight() {
        return right;
    }

    public void setRight(Categoria right) {
        this.right = right;
    }
}

class ArbolBinarioBusqueda {
    private Categoria raiz;

    public void agregar(String nombre) {
        raiz = agregarRecursivo(raiz, nombre);
    }

    private Categoria agregarRecursivo(Categoria actual, String nombre) {
        if (actual == null) {
            return new Categoria(nombre);
        }

        if (nombre.compareTo(actual.getNombre()) < 0) {
            actual.setLeft(agregarRecursivo(actual.getLeft(), nombre));
        } else if (nombre.compareTo(actual.getNombre()) > 0) {
            actual.setRight(agregarRecursivo(actual.getRight(), nombre));
        }

        return actual;
    }

    public void mostrar() {
        mostrarRecursivo(raiz);
    }

    private void mostrarRecursivo(Categoria actual) {
        if (actual != null) {
            mostrarRecursivo(actual.getLeft());
            System.out.println(actual.getNombre());
            mostrarRecursivo(actual.getRight());
        }
    }

    public Categoria buscar(String nombre) {
        return buscarRecursivo(raiz, nombre);
    }

    private Categoria buscarRecursivo(Categoria actual, String nombre) {
        if (actual == null || actual.getNombre().equals(nombre)) {
            return actual;
        }

        if (nombre.compareTo(actual.getNombre()) < 0) {
            return buscarRecursivo(actual.getLeft(), nombre);
        } else {
            return buscarRecursivo(actual.getRight(), nombre);
        }
    }

    public boolean eliminar(String nombre) {
        if (buscar(nombre) == null) {
            return false;
        }
        raiz = eliminarRecursivo(raiz, nombre);
        return true;
    }

    private Categoria eliminarRecursivo(Categoria actual, String nombre) {
        if (actual == null) {
            return null;
        }

        if (nombre.equals(actual.getNombre())) {
            if (actual.getLeft() == null && actual.getRight() == null) {
                return null;
            }

            if (actual.getRight() == null) {
                return actual.getLeft();
            }

            if (actual.getLeft() == null) {
                return actual.getRight();
            }

            String menorValor = encontrarMenorValor(actual.getRight());
            actual.setNombre(menorValor);
            actual.setRight(eliminarRecursivo(actual.getRight(), menorValor));
            return actual;
        }

        if (nombre.compareTo(actual.getNombre()) < 0) {
            actual.setLeft(eliminarRecursivo(actual.getLeft(), nombre));
            return actual;
        }

        actual.setRight(eliminarRecursivo(actual.getRight(), nombre));
        return actual;
    }

    private String encontrarMenorValor(Categoria root) {
        return root.getLeft() == null ? root.getNombre() : encontrarMenorValor(root.getLeft());
    }
     public boolean estaVacio() {
        return raiz == null;
    }
}